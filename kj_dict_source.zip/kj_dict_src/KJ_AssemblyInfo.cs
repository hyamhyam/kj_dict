﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("hyam")]
[assembly: AssemblyCopyright("(C) hyam")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]     

[assembly: AssemblyVersion("4.0.3.0")]

// exeのみの配布は行わない事にする。
// originalのexeにはこだわらないので厳密名の署名は行わない
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
